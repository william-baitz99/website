# Website sachlich als Freelancer-Profil ausrichten

## Ziel
Die Website stellt William Baitz, seine Berufserfahrung, seine Fachgebiete und seine Arbeitsweise vor. Verkaufsorientierte Aussagen, Erfolgsversprechen und künstliche Dringlichkeit entfallen.

## Umsetzung
- Die Startseite von einer Marketing-Einstiegsseite zu einem persönlichen Freelancer-Profil umformulieren.
- Überschriften und Texte zu SEO, GEO, CRO und Shopify nüchtern als Tätigkeitsfelder beschreiben.
- Aussagen wie „Mehr Sichtbarkeit“, „besser wachsen“, „besser als Agentur“, „Hebel“, „Diagnose“ und vergleichbare Werbeformulierungen entfernen.
- Kennzahlen nur als überprüfbare berufliche Fakten zeigen; keine Wirkungs- oder Erfolgsversprechen ableiten.
- CRO- und Shopify-Seite als sachliche Leistungsübersichten formulieren: Aufgaben, verwendete Methoden, Ablauf und mögliche Zusammenarbeit.
- Preisangaben beibehalten, aber Empfehlungen, kostenlose Lockangebote und verkaufsorientierte Abschlussblöcke neutralisieren.
- Kontaktseite als allgemeine Projektanfrage gestalten; der Loom-Shopcheck bleibt als mögliche Form der Ersteinschätzung, nicht als Werbeangebot.
- Navigation, interne Seiten, Wolf-of-SEO-Link und Kontaktverweise funktionsfähig lassen.
- Seitentitel und Beschreibungen ebenfalls sachlich formulieren.
- Desktop und Mobil auf Textlängen, Darstellung und Links prüfen.

## Technische Details
- Änderungen bleiben auf Texte und die dafür nötigen kleinen Darstellungsanpassungen begrenzt.
- Bestehende Gestaltung, Seitenstruktur und rechtliche Seiten bleiben erhalten.
- Keine neuen Referenzen, Erfolge, Preise oder Kontaktdaten erfinden.
