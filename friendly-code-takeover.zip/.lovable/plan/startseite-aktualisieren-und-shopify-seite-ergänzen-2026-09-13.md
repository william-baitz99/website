# Startseite aktualisieren und Shopify-Seite ergänzen

## Ziel
Die Startseite wird klarer und weniger wiederholend. Eine neue Leistungsseite erklärt Shopify-Entwicklung im bestehenden Stil und führt Interessenten zur Kontaktaufnahme.

## Umsetzung
- Auf der Startseite die Leistungswiederholung im sichtbaren Einstieg auf zwei Nennungen reduzieren: Zusatz neben „Freelancer“ und Text unter dem Namen entfernen.
- Projektzahl auf „125 Projekte betreut“ aktualisieren.
- Die Shopify-Kachel mit einer neuen Seite `/shopify-entwicklung` verbinden.
- Die „Wolf of SEO“-Kachel als externen Link zu `https://wolf-of-seo.de/` öffnen.
- Den vorläufigen Blogblock entfernen und dort den Kontaktblock platzieren; die bisherige untere Shop-Diagnose-Fläche entfällt, damit die Diagnose nur einmal beworben wird.
- Den Kontaktblock mit den bereits bekannten Angaben aus der Kontaktseite zeigen: LinkedIn ist aktiv, E-Mail, Telefon und Calendly bleiben klar als noch offene Angaben gekennzeichnet.
- Eine Shopify-Entwicklungsseite im Stil der CRO-Seite erstellen: klarer Einstieg, typische Shop-Probleme und Lösungen, Arbeitsablauf, Leistungsbereiche, FAQ und Kontaktaufforderung.
- Desktop und Mobil prüfen sowie alle neuen Links testen.

## Technische Details
- Neue TanStack-Route `/shopify-entwicklung` mit eigener Seitenbeschreibung und Social-Metadaten.
- Bestehende Farben, Typografie, Kopfzeile, Fußzeile und Seitenmuster weiterverwenden.
- Keine Preise, Referenzen oder Kontaktdaten erfinden, die nicht bereits vorliegen.