# Kontaktseite und Shop-Diagnose

## Ziel
Die Startseite führt klar zur kostenlosen Shop-Diagnose. Eine neue Kontaktseite stellt das etwa zehnminütige Loom-Video mit konkreten CRO- und SEO-Hinweisen in den Mittelpunkt; ein Erstgespräch bleibt eine nachgelagerte Option.

## Umsetzung
- Header-CTA auf „Shop prüfen lassen“ ändern und mit der neuen Kontaktseite verlinken.
- Den Freelancer-Vorteil auf der Startseite als „Schnell & fester Ansprechpartner“ formulieren.
- Den bisherigen Kontaktbereich und die Shopanalyse-Kachel inhaltlich auf die kostenlose Shop-Diagnose ausrichten.
- Eine eigenständige Kontaktseite im bestehenden Bento-Stil gestalten, mit Portrait, Ablauf und prominentem Anfrageformular.
- Formularfelder für Name, E-Mail, Shop-URL sowie gewünschte CRO-/SEO-Schwerpunkte ergänzen.
- E-Mail, Telefon, LinkedIn und Calendly anzeigen; die drei noch fehlenden Angaben zunächst als klar erkennbare Platzhalter führen.
- Formularanfragen serverseitig in ein verbundenes Google Sheet schreiben und verständliche Erfolgs- und Fehlerzustände anzeigen.
- Darstellung und Formularfluss auf Desktop und Mobil prüfen.

## Technische Details
- Neue TanStack-Route `/kontakt` mit eigener Seitenbeschreibung und Social-Metadaten.
- Google Sheets wird ausschließlich serverseitig über die Projektverbindung angesprochen; Zugangsdaten gelangen nicht in den Browser.
- Für die Speicherung wird ein Sheet mit einer Kopfzeile für Zeitpunkt, Name, E-Mail, Shop-URL und Anliegen verwendet.
